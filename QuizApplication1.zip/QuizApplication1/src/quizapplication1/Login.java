package quizapplication1;
import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.*;




public class Login extends JFrame implements ActionListener{
    JButton rules,back;
    JTextField tfname;
    Login(){
        getContentPane().setBackground( Color.PINK);
       setLayout(null);
        
        //image setup
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("Icons/login.jpeg"));
       JLabel image = new JLabel(i1);
       image.setBounds(0,0,600,500);
        add(image);
         
         //heading
         JLabel heading = new JLabel ("Simple Minds");
         heading.setBounds(750,300,60,45);
        
         heading.setFont(new Font("Viner Hand ITC", Font.BOLD , 40));
      heading.setForeground(new Color(30,144,254));
         add(heading);
         
         //enter name
         JLabel name = new JLabel ("Enter Your Name");
         name.setBounds(810,150,300,20);
        
         name.setFont(new Font("Mongolian Baiti", Font.BOLD , 10));
        name.setForeground(new Color(30,144,254));
         add(name);
         //textfield
          tfname = new JTextField();
         tfname.setBounds(735,200,300,25);
        
         tfname.setFont(new Font("Times New Roman", Font.BOLD , 20));
         add(tfname);
         
         
         //button create
          rules = new JButton("RULES");
         rules.setBounds(735,270,120,35);
        rules.setBackground(new Color(30,144,254));
         rules.setForeground(Color.BLACK);
         rules.addActionListener(this);
         add(rules);
         
         //back button
          back = new JButton("BACK");
         back.setBounds(915,270,120,35);
        back.setBackground(new Color(30,144,254));
         back.setForeground(Color.BLACK);
         back.addActionListener(this);
         add(back);
         
         
       
        
         //size setup
         setSize(1200,500);
        setLocation(200,150);
     setVisible(true);
     
     //psvm class
    }
    @Override
     public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == rules) {
            String name = tfname.getText();
            setVisible(false);
            
            new Rules(name);
        } else if (ae.getSource() == back) {
            setVisible(false);
        }
    }
    
    public static void main(String[] args) {
        new Login();
    }
}
    