import java.util.ArrayList;
import java.util.Scanner;

public class EventManagementSystem {

    private ArrayList<Event> events;

    public EventManagementSystem() {
        events = new ArrayList<>();
    }

    public void addEvent(String name, String date, String time, String location) {
        Event event = new Event(name, date, time, location);
        events.add(event);
    }

    public void removeEvent(String name) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).getName().equals(name)) {
                events.remove(i);
                break;
            }
        }
    }

    public void printEvents() {
        for (Event event : events) {
            System.out.println(event);
        }
    }

    public static void main(String[] args) {
        EventManagementSystem eventManager = new EventManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add event");
            System.out.println("2. Remove event");
            System.out.println("3. Print events");
            System.out.println("4. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("Enter the event name: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter the event date: ");
                    String date = scanner.nextLine();
                    System.out.println("Enter the event time: ");
                    String time = scanner.nextLine();
                    System.out.println("Enter the event location: ");
                    String location = scanner.nextLine();
                    eventManager.addEvent(name, date, time, location);
                    break;
                case 2:
                    System.out.println("Enter the event name to remove: ");
                    String eventName = scanner.nextLine();
                    eventManager.removeEvent(eventName);
                    break;
                case 3:
                    eventManager.printEvents();
                    break;
                case 4:
                    System.exit(0);
                    break;
            }
        }
    }
}

class Event {

    private String name;
    private String date;
    private String time;
    private String location;

    public Event(String name, String date, String time, String location) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }

    @Override
    public String toString() {
        return "Event{" +
                "name='" + name + '\'' +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}
